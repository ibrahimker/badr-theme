<?php
/* Template Name: Works Template */
get_header();
?>
<!-- Portfolio section -->
<section id="portfolio">
	<div class="container">
		<div class="row">
			<?php projects_content(); ?>
		</div>
	</div>
</section>
<?php get_footer(); ?>
