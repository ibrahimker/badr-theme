Cara install:
1. Upload themenya
2. Upload pluginnya dan diaktifkan. Theme badr ini dependent ke plugin-plugin itu
3. Upload data data untuk website yang ada pakai menu import yang ada di dashboard.